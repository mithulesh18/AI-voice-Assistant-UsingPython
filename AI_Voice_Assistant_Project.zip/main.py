
import speech_recognition as sr
import pyttsx3
import datetime
import webbrowser

engine = pyttsx3.init()

def speak(text):
    engine.say(text)
    engine.runAndWait()

def greet_user():
    hour = datetime.datetime.now().hour
    if hour < 12:
        speak("Good morning!")
    elif hour < 18:
        speak("Good afternoon!")
    else:
        speak("Good evening!")
    speak("I am your assistant. How can I help you today?")

def take_command():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("Recognizing...")
        query = r.recognize_google(audio, language='en-in')
        print(f"You said: {query}")
        return query.lower()
    except Exception as e:
        print("Sorry, could not understand. Please say that again.")
        return "None"

def main():
    greet_user()
    while True:
        query = take_command()
        if "wikipedia" in query:
            speak("Searching Wikipedia...")
            # Wikipedia logic here
        elif "open google" in query:
            webbrowser.open("https://www.google.com")
        elif "stop" in query:
            speak("Goodbye!")
            break

if __name__ == "__main__":
    main()
